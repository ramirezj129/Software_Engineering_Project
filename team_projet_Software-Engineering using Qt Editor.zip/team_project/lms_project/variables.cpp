#include "variables.h"
#include <QString>
#include <QVector>

//set global variables to be used throughout the different windows
QString user_id = "";
QString curr_path = "";
QString student_selectedCourse = "";
QString admin_selectedCourse = "";
QString selected_course = "";
