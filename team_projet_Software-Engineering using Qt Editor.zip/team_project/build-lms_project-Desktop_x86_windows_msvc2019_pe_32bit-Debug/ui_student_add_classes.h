/********************************************************************************
** Form generated from reading UI file 'student_add_classes.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STUDENT_ADD_CLASSES_H
#define UI_STUDENT_ADD_CLASSES_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_student_add_classes
{
public:
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QLabel *label_2;
    QComboBox *comboBox;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QDialog *student_add_classes)
    {
        if (student_add_classes->objectName().isEmpty())
            student_add_classes->setObjectName(QString::fromUtf8("student_add_classes"));
        student_add_classes->resize(201, 135);
        verticalLayout_2 = new QVBoxLayout(student_add_classes);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label = new QLabel(student_add_classes);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font;
        font.setPointSize(24);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label);

        label_2 = new QLabel(student_add_classes);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_2);

        comboBox = new QComboBox(student_add_classes);
        comboBox->setObjectName(QString::fromUtf8("comboBox"));

        verticalLayout->addWidget(comboBox);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        pushButton = new QPushButton(student_add_classes);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        horizontalLayout->addWidget(pushButton);

        pushButton_2 = new QPushButton(student_add_classes);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));

        horizontalLayout->addWidget(pushButton_2);


        verticalLayout->addLayout(horizontalLayout);


        verticalLayout_2->addLayout(verticalLayout);


        retranslateUi(student_add_classes);
        QObject::connect(pushButton_2, SIGNAL(clicked()), student_add_classes, SLOT(hide()));

        QMetaObject::connectSlotsByName(student_add_classes);
    } // setupUi

    void retranslateUi(QDialog *student_add_classes)
    {
        student_add_classes->setWindowTitle(QCoreApplication::translate("student_add_classes", "Add Course", nullptr));
        label->setText(QCoreApplication::translate("student_add_classes", "Add Course", nullptr));
        label_2->setText(QCoreApplication::translate("student_add_classes", "Select a course to add:", nullptr));
        pushButton->setText(QCoreApplication::translate("student_add_classes", "Add Class", nullptr));
        pushButton_2->setText(QCoreApplication::translate("student_add_classes", "Cancel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class student_add_classes: public Ui_student_add_classes {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STUDENT_ADD_CLASSES_H
