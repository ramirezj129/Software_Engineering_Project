/********************************************************************************
** Form generated from reading UI file 'faculty_course_information.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FACULTY_COURSE_INFORMATION_H
#define UI_FACULTY_COURSE_INFORMATION_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_faculty_course_information
{
public:
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QLabel *courseAssignment;
    QGroupBox *groupBox_3;
    QHBoxLayout *horizontalLayout_10;
    QVBoxLayout *verticalLayout_4;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QLabel *firstName;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_3;
    QLabel *lastName;
    QHBoxLayout *horizontalLayout_8;
    QLabel *label_6;
    QLabel *phone;
    QComboBox *comboBox;
    QTableWidget *tableWidget;
    QLabel *curr_grade;
    QLabel *label;

    void setupUi(QDialog *faculty_course_information)
    {
        if (faculty_course_information->objectName().isEmpty())
            faculty_course_information->setObjectName(QString::fromUtf8("faculty_course_information"));
        faculty_course_information->resize(600, 370);
        pushButton = new QPushButton(faculty_course_information);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(120, 330, 171, 31));
        pushButton_2 = new QPushButton(faculty_course_information);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(330, 330, 171, 31));
        courseAssignment = new QLabel(faculty_course_information);
        courseAssignment->setObjectName(QString::fromUtf8("courseAssignment"));
        courseAssignment->setGeometry(QRect(270, 0, 181, 41));
        groupBox_3 = new QGroupBox(faculty_course_information);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        groupBox_3->setGeometry(QRect(0, 50, 301, 228));
        horizontalLayout_10 = new QHBoxLayout(groupBox_3);
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_2 = new QLabel(groupBox_3);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_2->addWidget(label_2);

        firstName = new QLabel(groupBox_3);
        firstName->setObjectName(QString::fromUtf8("firstName"));

        horizontalLayout_2->addWidget(firstName);


        verticalLayout_3->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_3 = new QLabel(groupBox_3);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_3->addWidget(label_3);

        lastName = new QLabel(groupBox_3);
        lastName->setObjectName(QString::fromUtf8("lastName"));

        horizontalLayout_3->addWidget(lastName);


        verticalLayout_3->addLayout(horizontalLayout_3);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        label_6 = new QLabel(groupBox_3);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout_8->addWidget(label_6);

        phone = new QLabel(groupBox_3);
        phone->setObjectName(QString::fromUtf8("phone"));

        horizontalLayout_8->addWidget(phone);


        verticalLayout_3->addLayout(horizontalLayout_8);


        verticalLayout_4->addLayout(verticalLayout_3);


        horizontalLayout_10->addLayout(verticalLayout_4);

        comboBox = new QComboBox(faculty_course_information);
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(380, 50, 121, 21));
        tableWidget = new QTableWidget(faculty_course_information);
        if (tableWidget->columnCount() < 1)
            tableWidget->setColumnCount(1);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setGeometry(QRect(370, 80, 151, 181));
        tableWidget->setRowCount(0);
        tableWidget->setColumnCount(1);
        curr_grade = new QLabel(faculty_course_information);
        curr_grade->setObjectName(QString::fromUtf8("curr_grade"));
        curr_grade->setGeometry(QRect(440, 270, 55, 16));
        label = new QLabel(faculty_course_information);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(380, 270, 55, 16));

        retranslateUi(faculty_course_information);

        QMetaObject::connectSlotsByName(faculty_course_information);
    } // setupUi

    void retranslateUi(QDialog *faculty_course_information)
    {
        faculty_course_information->setWindowTitle(QCoreApplication::translate("faculty_course_information", "Course Information", nullptr));
        pushButton->setText(QCoreApplication::translate("faculty_course_information", "Apply", nullptr));
        pushButton_2->setText(QCoreApplication::translate("faculty_course_information", "Cancel", nullptr));
        courseAssignment->setText(QCoreApplication::translate("faculty_course_information", "TextLabel", nullptr));
        groupBox_3->setTitle(QCoreApplication::translate("faculty_course_information", "Student's Information", nullptr));
        label_2->setText(QCoreApplication::translate("faculty_course_information", "First Name:", nullptr));
        firstName->setText(QCoreApplication::translate("faculty_course_information", "John", nullptr));
        label_3->setText(QCoreApplication::translate("faculty_course_information", "Last Name:", nullptr));
        lastName->setText(QCoreApplication::translate("faculty_course_information", "Doe", nullptr));
        label_6->setText(QCoreApplication::translate("faculty_course_information", "Phone Number:", nullptr));
        phone->setText(QCoreApplication::translate("faculty_course_information", "7131231234", nullptr));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("faculty_course_information", "Grade", nullptr));
        curr_grade->setText(QCoreApplication::translate("faculty_course_information", "TextLabel", nullptr));
        label->setText(QCoreApplication::translate("faculty_course_information", "Average:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class faculty_course_information: public Ui_faculty_course_information {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FACULTY_COURSE_INFORMATION_H
