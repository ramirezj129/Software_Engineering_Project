/********************************************************************************
** Form generated from reading UI file 'student_dashboard.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STUDENT_DASHBOARD_H
#define UI_STUDENT_DASHBOARD_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_student_dashboard
{
public:
    QLabel *label;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout;
    QListView *listView;
    QPushButton *pushButton;
    QPushButton *pushButton_3;
    QPushButton *pushButton_2;
    QGroupBox *groupBox_3;
    QHBoxLayout *horizontalLayout_10;
    QVBoxLayout *verticalLayout_4;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QLabel *firstName;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_3;
    QLabel *lastName;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_4;
    QLabel *address;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_7;
    QLabel *city;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_8;
    QLabel *state;
    QHBoxLayout *horizontalLayout_9;
    QLabel *label_9;
    QLabel *zip;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label_5;
    QLabel *dob;
    QHBoxLayout *horizontalLayout_8;
    QLabel *label_6;
    QLabel *phone;
    QPushButton *pushButton_4;
    QPushButton *pushButton_6;

    void setupUi(QDialog *student_dashboard)
    {
        if (student_dashboard->objectName().isEmpty())
            student_dashboard->setObjectName(QString::fromUtf8("student_dashboard"));
        student_dashboard->resize(602, 495);
        label = new QLabel(student_dashboard);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(9, 9, 260, 33));
        QFont font;
        font.setPointSize(20);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        groupBox = new QGroupBox(student_dashboard);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(320, 50, 268, 397));
        verticalLayout = new QVBoxLayout(groupBox);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        listView = new QListView(groupBox);
        listView->setObjectName(QString::fromUtf8("listView"));

        verticalLayout->addWidget(listView);

        pushButton = new QPushButton(groupBox);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        verticalLayout->addWidget(pushButton);

        pushButton_3 = new QPushButton(groupBox);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));

        verticalLayout->addWidget(pushButton_3);

        pushButton_2 = new QPushButton(groupBox);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));

        verticalLayout->addWidget(pushButton_2);

        groupBox_3 = new QGroupBox(student_dashboard);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        groupBox_3->setGeometry(QRect(10, 49, 301, 228));
        horizontalLayout_10 = new QHBoxLayout(groupBox_3);
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_2 = new QLabel(groupBox_3);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_2->addWidget(label_2);

        firstName = new QLabel(groupBox_3);
        firstName->setObjectName(QString::fromUtf8("firstName"));

        horizontalLayout_2->addWidget(firstName);


        verticalLayout_3->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_3 = new QLabel(groupBox_3);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_3->addWidget(label_3);

        lastName = new QLabel(groupBox_3);
        lastName->setObjectName(QString::fromUtf8("lastName"));

        horizontalLayout_3->addWidget(lastName);


        verticalLayout_3->addLayout(horizontalLayout_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        label_4 = new QLabel(groupBox_3);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_4->addWidget(label_4);

        address = new QLabel(groupBox_3);
        address->setObjectName(QString::fromUtf8("address"));

        horizontalLayout_4->addWidget(address);


        verticalLayout_3->addLayout(horizontalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        label_7 = new QLabel(groupBox_3);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        horizontalLayout_5->addWidget(label_7);

        city = new QLabel(groupBox_3);
        city->setObjectName(QString::fromUtf8("city"));

        horizontalLayout_5->addWidget(city);


        verticalLayout_3->addLayout(horizontalLayout_5);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        label_8 = new QLabel(groupBox_3);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        horizontalLayout_6->addWidget(label_8);

        state = new QLabel(groupBox_3);
        state->setObjectName(QString::fromUtf8("state"));

        horizontalLayout_6->addWidget(state);


        verticalLayout_3->addLayout(horizontalLayout_6);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        label_9 = new QLabel(groupBox_3);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        horizontalLayout_9->addWidget(label_9);

        zip = new QLabel(groupBox_3);
        zip->setObjectName(QString::fromUtf8("zip"));

        horizontalLayout_9->addWidget(zip);


        verticalLayout_3->addLayout(horizontalLayout_9);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        label_5 = new QLabel(groupBox_3);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        horizontalLayout_7->addWidget(label_5);

        dob = new QLabel(groupBox_3);
        dob->setObjectName(QString::fromUtf8("dob"));

        horizontalLayout_7->addWidget(dob);


        verticalLayout_3->addLayout(horizontalLayout_7);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        label_6 = new QLabel(groupBox_3);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout_8->addWidget(label_6);

        phone = new QLabel(groupBox_3);
        phone->setObjectName(QString::fromUtf8("phone"));

        horizontalLayout_8->addWidget(phone);


        verticalLayout_3->addLayout(horizontalLayout_8);


        verticalLayout_4->addLayout(verticalLayout_3);

        pushButton_4 = new QPushButton(groupBox_3);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));

        verticalLayout_4->addWidget(pushButton_4);


        horizontalLayout_10->addLayout(verticalLayout_4);

        pushButton_6 = new QPushButton(student_dashboard);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(260, 460, 75, 23));

        retranslateUi(student_dashboard);
        QObject::connect(pushButton_6, SIGNAL(clicked()), student_dashboard, SLOT(close()));

        QMetaObject::connectSlotsByName(student_dashboard);
    } // setupUi

    void retranslateUi(QDialog *student_dashboard)
    {
        student_dashboard->setWindowTitle(QCoreApplication::translate("student_dashboard", "Student Dashboard", nullptr));
        label->setText(QCoreApplication::translate("student_dashboard", "Student Dashboard", nullptr));
        groupBox->setTitle(QCoreApplication::translate("student_dashboard", "My Courses", nullptr));
        pushButton->setText(QCoreApplication::translate("student_dashboard", "Course Details", nullptr));
        pushButton_3->setText(QCoreApplication::translate("student_dashboard", "Add Course", nullptr));
        pushButton_2->setText(QCoreApplication::translate("student_dashboard", "Drop Course", nullptr));
        groupBox_3->setTitle(QCoreApplication::translate("student_dashboard", "My Information", nullptr));
        label_2->setText(QCoreApplication::translate("student_dashboard", "First Name:", nullptr));
        firstName->setText(QCoreApplication::translate("student_dashboard", "John", nullptr));
        label_3->setText(QCoreApplication::translate("student_dashboard", "Last Name:", nullptr));
        lastName->setText(QCoreApplication::translate("student_dashboard", "Doe", nullptr));
        label_4->setText(QCoreApplication::translate("student_dashboard", "Address:", nullptr));
        address->setText(QCoreApplication::translate("student_dashboard", "123 Street Drive", nullptr));
        label_7->setText(QCoreApplication::translate("student_dashboard", "City:", nullptr));
        city->setText(QCoreApplication::translate("student_dashboard", "Houston", nullptr));
        label_8->setText(QCoreApplication::translate("student_dashboard", "State:", nullptr));
        state->setText(QCoreApplication::translate("student_dashboard", "TX", nullptr));
        label_9->setText(QCoreApplication::translate("student_dashboard", "Zip Code:", nullptr));
        zip->setText(QCoreApplication::translate("student_dashboard", "77081", nullptr));
        label_5->setText(QCoreApplication::translate("student_dashboard", "Date of Birth:", nullptr));
        dob->setText(QCoreApplication::translate("student_dashboard", "01/01/1990", nullptr));
        label_6->setText(QCoreApplication::translate("student_dashboard", "Phone Number:", nullptr));
        phone->setText(QCoreApplication::translate("student_dashboard", "7131231234", nullptr));
        pushButton_4->setText(QCoreApplication::translate("student_dashboard", "Edit Your Information", nullptr));
        pushButton_6->setText(QCoreApplication::translate("student_dashboard", "Exit", nullptr));
    } // retranslateUi

};

namespace Ui {
    class student_dashboard: public Ui_student_dashboard {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STUDENT_DASHBOARD_H
