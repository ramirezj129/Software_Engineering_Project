/********************************************************************************
** Form generated from reading UI file 'admineditinfo.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADMINEDITINFO_H
#define UI_ADMINEDITINFO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_admineditinfo
{
public:
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout_2;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QVBoxLayout *verticalLayout;
    QLineEdit *firstName;
    QLineEdit *lastName;
    QLineEdit *address;
    QLineEdit *city;
    QLineEdit *state;
    QLineEdit *zip;
    QLineEdit *dob;
    QLineEdit *phone;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QDialog *admineditinfo)
    {
        if (admineditinfo->objectName().isEmpty())
            admineditinfo->setObjectName(QString::fromUtf8("admineditinfo"));
        admineditinfo->resize(263, 303);
        layoutWidget = new QWidget(admineditinfo);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(20, 30, 221, 239));
        verticalLayout_3 = new QVBoxLayout(layoutWidget);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout_2->addWidget(label);

        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout_2->addWidget(label_2);

        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        verticalLayout_2->addWidget(label_3);

        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        verticalLayout_2->addWidget(label_4);

        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout_2->addWidget(label_5);

        label_6 = new QLabel(layoutWidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        verticalLayout_2->addWidget(label_6);

        label_7 = new QLabel(layoutWidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        verticalLayout_2->addWidget(label_7);

        label_8 = new QLabel(layoutWidget);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        verticalLayout_2->addWidget(label_8);


        horizontalLayout->addLayout(verticalLayout_2);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        firstName = new QLineEdit(layoutWidget);
        firstName->setObjectName(QString::fromUtf8("firstName"));

        verticalLayout->addWidget(firstName);

        lastName = new QLineEdit(layoutWidget);
        lastName->setObjectName(QString::fromUtf8("lastName"));

        verticalLayout->addWidget(lastName);

        address = new QLineEdit(layoutWidget);
        address->setObjectName(QString::fromUtf8("address"));

        verticalLayout->addWidget(address);

        city = new QLineEdit(layoutWidget);
        city->setObjectName(QString::fromUtf8("city"));

        verticalLayout->addWidget(city);

        state = new QLineEdit(layoutWidget);
        state->setObjectName(QString::fromUtf8("state"));

        verticalLayout->addWidget(state);

        zip = new QLineEdit(layoutWidget);
        zip->setObjectName(QString::fromUtf8("zip"));

        verticalLayout->addWidget(zip);

        dob = new QLineEdit(layoutWidget);
        dob->setObjectName(QString::fromUtf8("dob"));

        verticalLayout->addWidget(dob);

        phone = new QLineEdit(layoutWidget);
        phone->setObjectName(QString::fromUtf8("phone"));

        verticalLayout->addWidget(phone);


        horizontalLayout->addLayout(verticalLayout);


        verticalLayout_3->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        pushButton = new QPushButton(layoutWidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        horizontalLayout_2->addWidget(pushButton);

        pushButton_2 = new QPushButton(layoutWidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));

        horizontalLayout_2->addWidget(pushButton_2);


        verticalLayout_3->addLayout(horizontalLayout_2);


        retranslateUi(admineditinfo);

        QMetaObject::connectSlotsByName(admineditinfo);
    } // setupUi

    void retranslateUi(QDialog *admineditinfo)
    {
        admineditinfo->setWindowTitle(QCoreApplication::translate("admineditinfo", "Edit Student Information", nullptr));
        label->setText(QCoreApplication::translate("admineditinfo", "First Name:", nullptr));
        label_2->setText(QCoreApplication::translate("admineditinfo", "Last Name:", nullptr));
        label_3->setText(QCoreApplication::translate("admineditinfo", "Address:", nullptr));
        label_4->setText(QCoreApplication::translate("admineditinfo", "City:", nullptr));
        label_5->setText(QCoreApplication::translate("admineditinfo", "State:", nullptr));
        label_6->setText(QCoreApplication::translate("admineditinfo", "Zip Code:", nullptr));
        label_7->setText(QCoreApplication::translate("admineditinfo", "Date of Birth:", nullptr));
        label_8->setText(QCoreApplication::translate("admineditinfo", "Phone Number:", nullptr));
        pushButton->setText(QCoreApplication::translate("admineditinfo", "Save Changes", nullptr));
        pushButton_2->setText(QCoreApplication::translate("admineditinfo", "Exit", nullptr));
    } // retranslateUi

};

namespace Ui {
    class admineditinfo: public Ui_admineditinfo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADMINEDITINFO_H
