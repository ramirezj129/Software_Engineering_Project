/********************************************************************************
** Form generated from reading UI file 'admin_add_student.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADMIN_ADD_STUDENT_H
#define UI_ADMIN_ADD_STUDENT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_admin_add_student
{
public:
    QVBoxLayout *verticalLayout_3;
    QLabel *label;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_2;
    QLabel *label_11;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;
    QVBoxLayout *verticalLayout;
    QLineEdit *username;
    QLineEdit *password;
    QLineEdit *fname;
    QLineEdit *lname;
    QLineEdit *address;
    QLineEdit *city;
    QLineEdit *state;
    QLineEdit *zip;
    QLineEdit *dob;
    QLineEdit *number;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QDialog *admin_add_student)
    {
        if (admin_add_student->objectName().isEmpty())
            admin_add_student->setObjectName(QString::fromUtf8("admin_add_student"));
        admin_add_student->resize(262, 378);
        verticalLayout_3 = new QVBoxLayout(admin_add_student);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        label = new QLabel(admin_add_student);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font;
        font.setPointSize(18);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(label);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        label_2 = new QLabel(admin_add_student);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout_2->addWidget(label_2);

        label_11 = new QLabel(admin_add_student);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        verticalLayout_2->addWidget(label_11);

        label_3 = new QLabel(admin_add_student);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        verticalLayout_2->addWidget(label_3);

        label_4 = new QLabel(admin_add_student);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        verticalLayout_2->addWidget(label_4);

        label_5 = new QLabel(admin_add_student);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout_2->addWidget(label_5);

        label_6 = new QLabel(admin_add_student);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        verticalLayout_2->addWidget(label_6);

        label_7 = new QLabel(admin_add_student);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        verticalLayout_2->addWidget(label_7);

        label_8 = new QLabel(admin_add_student);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        verticalLayout_2->addWidget(label_8);

        label_9 = new QLabel(admin_add_student);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        verticalLayout_2->addWidget(label_9);

        label_10 = new QLabel(admin_add_student);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        verticalLayout_2->addWidget(label_10);


        horizontalLayout->addLayout(verticalLayout_2);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        username = new QLineEdit(admin_add_student);
        username->setObjectName(QString::fromUtf8("username"));
        username->setFocusPolicy(Qt::StrongFocus);

        verticalLayout->addWidget(username);

        password = new QLineEdit(admin_add_student);
        password->setObjectName(QString::fromUtf8("password"));

        verticalLayout->addWidget(password);

        fname = new QLineEdit(admin_add_student);
        fname->setObjectName(QString::fromUtf8("fname"));

        verticalLayout->addWidget(fname);

        lname = new QLineEdit(admin_add_student);
        lname->setObjectName(QString::fromUtf8("lname"));

        verticalLayout->addWidget(lname);

        address = new QLineEdit(admin_add_student);
        address->setObjectName(QString::fromUtf8("address"));

        verticalLayout->addWidget(address);

        city = new QLineEdit(admin_add_student);
        city->setObjectName(QString::fromUtf8("city"));

        verticalLayout->addWidget(city);

        state = new QLineEdit(admin_add_student);
        state->setObjectName(QString::fromUtf8("state"));

        verticalLayout->addWidget(state);

        zip = new QLineEdit(admin_add_student);
        zip->setObjectName(QString::fromUtf8("zip"));

        verticalLayout->addWidget(zip);

        dob = new QLineEdit(admin_add_student);
        dob->setObjectName(QString::fromUtf8("dob"));

        verticalLayout->addWidget(dob);

        number = new QLineEdit(admin_add_student);
        number->setObjectName(QString::fromUtf8("number"));

        verticalLayout->addWidget(number);


        horizontalLayout->addLayout(verticalLayout);


        verticalLayout_3->addLayout(horizontalLayout);

        pushButton = new QPushButton(admin_add_student);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        verticalLayout_3->addWidget(pushButton);

        pushButton_2 = new QPushButton(admin_add_student);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));

        verticalLayout_3->addWidget(pushButton_2);


        retranslateUi(admin_add_student);

        QMetaObject::connectSlotsByName(admin_add_student);
    } // setupUi

    void retranslateUi(QDialog *admin_add_student)
    {
        admin_add_student->setWindowTitle(QCoreApplication::translate("admin_add_student", "Add Student", nullptr));
        label->setText(QCoreApplication::translate("admin_add_student", "Add New Student", nullptr));
        label_2->setText(QCoreApplication::translate("admin_add_student", "Username:", nullptr));
        label_11->setText(QCoreApplication::translate("admin_add_student", "Password:", nullptr));
        label_3->setText(QCoreApplication::translate("admin_add_student", "First Name:", nullptr));
        label_4->setText(QCoreApplication::translate("admin_add_student", "Last Name:", nullptr));
        label_5->setText(QCoreApplication::translate("admin_add_student", "Address:", nullptr));
        label_6->setText(QCoreApplication::translate("admin_add_student", "City:", nullptr));
        label_7->setText(QCoreApplication::translate("admin_add_student", "State:", nullptr));
        label_8->setText(QCoreApplication::translate("admin_add_student", "Zip Code:", nullptr));
        label_9->setText(QCoreApplication::translate("admin_add_student", "Date of Birth:", nullptr));
        label_10->setText(QCoreApplication::translate("admin_add_student", "Phone Number:", nullptr));
        pushButton->setText(QCoreApplication::translate("admin_add_student", "Add Student", nullptr));
        pushButton_2->setText(QCoreApplication::translate("admin_add_student", "Cancel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class admin_add_student: public Ui_admin_add_student {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADMIN_ADD_STUDENT_H
