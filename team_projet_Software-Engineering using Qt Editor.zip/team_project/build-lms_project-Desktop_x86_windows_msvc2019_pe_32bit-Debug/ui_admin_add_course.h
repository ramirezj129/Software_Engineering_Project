/********************************************************************************
** Form generated from reading UI file 'admin_add_course.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADMIN_ADD_COURSE_H
#define UI_ADMIN_ADD_COURSE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_admin_add_course
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QLineEdit *addCourseText;
    QPushButton *addCourseButton;
    QPushButton *pushButton_2;

    void setupUi(QDialog *admin_add_course)
    {
        if (admin_add_course->objectName().isEmpty())
            admin_add_course->setObjectName(QString::fromUtf8("admin_add_course"));
        admin_add_course->resize(222, 177);
        verticalLayout = new QVBoxLayout(admin_add_course);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label = new QLabel(admin_add_course);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font;
        font.setPointSize(18);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label);

        addCourseText = new QLineEdit(admin_add_course);
        addCourseText->setObjectName(QString::fromUtf8("addCourseText"));

        verticalLayout->addWidget(addCourseText);

        addCourseButton = new QPushButton(admin_add_course);
        addCourseButton->setObjectName(QString::fromUtf8("addCourseButton"));

        verticalLayout->addWidget(addCourseButton);

        pushButton_2 = new QPushButton(admin_add_course);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));

        verticalLayout->addWidget(pushButton_2);


        retranslateUi(admin_add_course);

        QMetaObject::connectSlotsByName(admin_add_course);
    } // setupUi

    void retranslateUi(QDialog *admin_add_course)
    {
        admin_add_course->setWindowTitle(QCoreApplication::translate("admin_add_course", "Add Course", nullptr));
        label->setText(QCoreApplication::translate("admin_add_course", "Add a Course", nullptr));
        addCourseButton->setText(QCoreApplication::translate("admin_add_course", "Add Course", nullptr));
        pushButton_2->setText(QCoreApplication::translate("admin_add_course", "Cancel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class admin_add_course: public Ui_admin_add_course {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADMIN_ADD_COURSE_H
