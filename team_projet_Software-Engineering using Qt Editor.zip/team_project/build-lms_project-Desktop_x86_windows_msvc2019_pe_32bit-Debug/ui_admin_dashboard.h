/********************************************************************************
** Form generated from reading UI file 'admin_dashboard.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADMIN_DASHBOARD_H
#define UI_ADMIN_DASHBOARD_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_admin_dashboard
{
public:
    QPushButton *pushButton;
    QWidget *widget;
    QVBoxLayout *verticalLayout_4;
    QLabel *label;
    QHBoxLayout *horizontalLayout;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout;
    QListView *activeCourses;
    QPushButton *addCourse;
    QPushButton *deleteCourse;
    QGroupBox *groupBox_2;
    QVBoxLayout *verticalLayout_3;
    QVBoxLayout *verticalLayout_2;
    QListView *activeStudents;
    QPushButton *editStudent;
    QPushButton *addStudent;
    QPushButton *deleteStudent;

    void setupUi(QDialog *admin_dashboard)
    {
        if (admin_dashboard->objectName().isEmpty())
            admin_dashboard->setObjectName(QString::fromUtf8("admin_dashboard"));
        admin_dashboard->resize(571, 403);
        pushButton = new QPushButton(admin_dashboard);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(250, 370, 75, 23));
        widget = new QWidget(admin_dashboard);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(0, 9, 564, 353));
        verticalLayout_4 = new QVBoxLayout(widget);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font;
        font.setPointSize(18);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        label->setAlignment(Qt::AlignCenter);

        verticalLayout_4->addWidget(label);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        groupBox = new QGroupBox(widget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        verticalLayout = new QVBoxLayout(groupBox);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        activeCourses = new QListView(groupBox);
        activeCourses->setObjectName(QString::fromUtf8("activeCourses"));

        verticalLayout->addWidget(activeCourses);

        addCourse = new QPushButton(groupBox);
        addCourse->setObjectName(QString::fromUtf8("addCourse"));

        verticalLayout->addWidget(addCourse);

        deleteCourse = new QPushButton(groupBox);
        deleteCourse->setObjectName(QString::fromUtf8("deleteCourse"));

        verticalLayout->addWidget(deleteCourse);


        horizontalLayout->addWidget(groupBox);

        groupBox_2 = new QGroupBox(widget);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        verticalLayout_3 = new QVBoxLayout(groupBox_2);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        activeStudents = new QListView(groupBox_2);
        activeStudents->setObjectName(QString::fromUtf8("activeStudents"));

        verticalLayout_2->addWidget(activeStudents);

        editStudent = new QPushButton(groupBox_2);
        editStudent->setObjectName(QString::fromUtf8("editStudent"));

        verticalLayout_2->addWidget(editStudent);

        addStudent = new QPushButton(groupBox_2);
        addStudent->setObjectName(QString::fromUtf8("addStudent"));

        verticalLayout_2->addWidget(addStudent);

        deleteStudent = new QPushButton(groupBox_2);
        deleteStudent->setObjectName(QString::fromUtf8("deleteStudent"));

        verticalLayout_2->addWidget(deleteStudent);


        verticalLayout_3->addLayout(verticalLayout_2);


        horizontalLayout->addWidget(groupBox_2);


        verticalLayout_4->addLayout(horizontalLayout);


        retranslateUi(admin_dashboard);
        QObject::connect(pushButton, SIGNAL(clicked()), admin_dashboard, SLOT(close()));

        QMetaObject::connectSlotsByName(admin_dashboard);
    } // setupUi

    void retranslateUi(QDialog *admin_dashboard)
    {
        admin_dashboard->setWindowTitle(QCoreApplication::translate("admin_dashboard", "Admin Dashboard", nullptr));
        pushButton->setText(QCoreApplication::translate("admin_dashboard", "Exit", nullptr));
        label->setText(QCoreApplication::translate("admin_dashboard", "ADMIN DASHBOARD", nullptr));
        groupBox->setTitle(QCoreApplication::translate("admin_dashboard", "Course List", nullptr));
        addCourse->setText(QCoreApplication::translate("admin_dashboard", "Add Course", nullptr));
        deleteCourse->setText(QCoreApplication::translate("admin_dashboard", "Delete Course", nullptr));
        groupBox_2->setTitle(QCoreApplication::translate("admin_dashboard", "Students List", nullptr));
        editStudent->setText(QCoreApplication::translate("admin_dashboard", "Edit Student", nullptr));
        addStudent->setText(QCoreApplication::translate("admin_dashboard", "Add Student", nullptr));
        deleteStudent->setText(QCoreApplication::translate("admin_dashboard", "Delete Student", nullptr));
    } // retranslateUi

};

namespace Ui {
    class admin_dashboard: public Ui_admin_dashboard {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADMIN_DASHBOARD_H
