/********************************************************************************
** Form generated from reading UI file 'student_course.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STUDENT_COURSE_H
#define UI_STUDENT_COURSE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_student_course
{
public:
    QVBoxLayout *verticalLayout_2;
    QLabel *courseName;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout;
    QTableWidget *tableWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLabel *curr_grade;
    QPushButton *pushButton;

    void setupUi(QDialog *student_course)
    {
        if (student_course->objectName().isEmpty())
            student_course->setObjectName(QString::fromUtf8("student_course"));
        student_course->resize(294, 477);
        verticalLayout_2 = new QVBoxLayout(student_course);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        courseName = new QLabel(student_course);
        courseName->setObjectName(QString::fromUtf8("courseName"));
        QFont font;
        font.setPointSize(24);
        font.setBold(true);
        font.setWeight(75);
        courseName->setFont(font);
        courseName->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(courseName);

        groupBox = new QGroupBox(student_course);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        verticalLayout = new QVBoxLayout(groupBox);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        tableWidget = new QTableWidget(groupBox);
        if (tableWidget->columnCount() < 1)
            tableWidget->setColumnCount(1);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        if (tableWidget->rowCount() < 1)
            tableWidget->setRowCount(1);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setVerticalHeaderItem(0, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        __qtablewidgetitem2->setTextAlignment(Qt::AlignCenter);
        __qtablewidgetitem2->setFlags(Qt::ItemIsEnabled);
        tableWidget->setItem(0, 0, __qtablewidgetitem2);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setShowGrid(false);
        tableWidget->setGridStyle(Qt::NoPen);

        verticalLayout->addWidget(tableWidget);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(groupBox);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font1;
        font1.setPointSize(12);
        font1.setBold(true);
        font1.setWeight(75);
        label->setFont(font1);

        horizontalLayout->addWidget(label);

        curr_grade = new QLabel(groupBox);
        curr_grade->setObjectName(QString::fromUtf8("curr_grade"));
        curr_grade->setFont(font1);
        curr_grade->setAlignment(Qt::AlignCenter);

        horizontalLayout->addWidget(curr_grade);


        verticalLayout->addLayout(horizontalLayout);

        pushButton = new QPushButton(groupBox);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(pushButton->sizePolicy().hasHeightForWidth());
        pushButton->setSizePolicy(sizePolicy);

        verticalLayout->addWidget(pushButton);


        verticalLayout_2->addWidget(groupBox);


        retranslateUi(student_course);

        QMetaObject::connectSlotsByName(student_course);
    } // setupUi

    void retranslateUi(QDialog *student_course)
    {
        student_course->setWindowTitle(QCoreApplication::translate("student_course", "Course Grades", nullptr));
        courseName->setText(QCoreApplication::translate("student_course", "CourseName", nullptr));
        groupBox->setTitle(QString());
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("student_course", "Grade", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->verticalHeaderItem(0);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("student_course", "Homework 1", nullptr));

        const bool __sortingEnabled = tableWidget->isSortingEnabled();
        tableWidget->setSortingEnabled(false);
        tableWidget->setSortingEnabled(__sortingEnabled);

        label->setText(QCoreApplication::translate("student_course", "Current Grade:", nullptr));
        curr_grade->setText(QCoreApplication::translate("student_course", "grade", nullptr));
        pushButton->setText(QCoreApplication::translate("student_course", "Close", nullptr));
    } // retranslateUi

};

namespace Ui {
    class student_course: public Ui_student_course {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STUDENT_COURSE_H
