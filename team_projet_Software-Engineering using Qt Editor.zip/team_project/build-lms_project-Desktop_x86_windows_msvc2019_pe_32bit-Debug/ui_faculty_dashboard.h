/********************************************************************************
** Form generated from reading UI file 'faculty_dashboard.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FACULTY_DASHBOARD_H
#define UI_FACULTY_DASHBOARD_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListView>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_faculty_dashboard
{
public:
    QLabel *label;
    QListView *listView;
    QPushButton *pushButton;

    void setupUi(QDialog *faculty_dashboard)
    {
        if (faculty_dashboard->objectName().isEmpty())
            faculty_dashboard->setObjectName(QString::fromUtf8("faculty_dashboard"));
        faculty_dashboard->resize(397, 441);
        label = new QLabel(faculty_dashboard);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(40, 20, 321, 41));
        QFont font;
        font.setPointSize(20);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        listView = new QListView(faculty_dashboard);
        listView->setObjectName(QString::fromUtf8("listView"));
        listView->setGeometry(QRect(30, 70, 331, 311));
        pushButton = new QPushButton(faculty_dashboard);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(30, 390, 331, 31));

        retranslateUi(faculty_dashboard);

        QMetaObject::connectSlotsByName(faculty_dashboard);
    } // setupUi

    void retranslateUi(QDialog *faculty_dashboard)
    {
        faculty_dashboard->setWindowTitle(QCoreApplication::translate("faculty_dashboard", "Faculty Dashboard", nullptr));
        label->setText(QCoreApplication::translate("faculty_dashboard", "Faculty Dashboard", nullptr));
        pushButton->setText(QCoreApplication::translate("faculty_dashboard", "Course Details", nullptr));
    } // retranslateUi

};

namespace Ui {
    class faculty_dashboard: public Ui_faculty_dashboard {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FACULTY_DASHBOARD_H
