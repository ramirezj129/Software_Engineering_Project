#include "variables.h"
#include <QString>

//set global variables to be used throughout the different windows
QString user_id = "";
QString curr_path = "";
QString student_selectedCourse = "";
